from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.core.dependencies import get_current_user
from app.core.permissions import require_roles
from app.models.user import User
from app.utils.enums import UserRole
from app.schemas.audit_log_schema import AuditLogResponse
from app.services.audit_log_service import get_audit_logs

router = APIRouter(
    prefix="/audit-logs",
    tags=["Audit Logs"],
)


@router.get(
    "/",
    response_model=list[AuditLogResponse],
)
def list_audit_logs(
    user_id: int | None = None,
    action: str | None = None,
    entity_type: str | None = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return get_audit_logs(
        db=db,
        user_id=user_id,
        action=action,
        entity_type=entity_type,
        skip=skip,
        limit=limit,
    )