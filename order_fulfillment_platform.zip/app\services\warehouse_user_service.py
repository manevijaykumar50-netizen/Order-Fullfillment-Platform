
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.user import User
from app.models.warehouse import Warehouse
from app.models.warehouse_user import WarehouseUser
from app.schemas.warehouse_user import WarehouseUserCreate
from app.utils.enums import UserRole


ALLOWED_ASSIGNMENT_ROLES = {
    UserRole.WAREHOUSE_MANAGER.value,
    UserRole.FULFILLMENT_AGENT.value,
}


def create_warehouse_user(
    db: Session,
    data: WarehouseUserCreate,
) -> WarehouseUser:
    warehouse = (
        db.query(Warehouse)
        .filter(Warehouse.id == data.warehouse_id)
        .first()
    )

    if warehouse is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Warehouse not found",
        )

    if not warehouse.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot assign users to an inactive warehouse",
        )

    user = (
        db.query(User)
        .filter(User.id == data.user_id)
        .first()
    )

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot assign an inactive user",
        )

    if user.role.name not in ALLOWED_ASSIGNMENT_ROLES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only Warehouse Managers and Fulfillment Agents can be assigned",
        )

    existing = (
        db.query(WarehouseUser)
        .filter(
            WarehouseUser.warehouse_id == data.warehouse_id,
            WarehouseUser.user_id == data.user_id,
        )
        .first()
    )

    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User is already assigned to this warehouse",
        )

    assignment = WarehouseUser(
        warehouse_id=data.warehouse_id,
        user_id=data.user_id,
        assignment_role=user.role.name,
    )

    db.add(assignment)
    db.commit()
    db.refresh(assignment)

    return assignment


def list_warehouse_users(
    db: Session,
    warehouse_id: int | None = None,
) -> list[WarehouseUser]:
    query = db.query(WarehouseUser)

    if warehouse_id is not None:
        warehouse = (
            db.query(Warehouse)
            .filter(Warehouse.id == warehouse_id)
            .first()
        )

        if warehouse is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Warehouse not found",
            )

        query = query.filter(
            WarehouseUser.warehouse_id == warehouse_id
        )

    return query.order_by(WarehouseUser.id).all()