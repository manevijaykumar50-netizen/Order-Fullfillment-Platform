
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.inventory import Inventory
from app.models.inventory_transaction import InventoryTransaction
from app.models.product import Product
from app.models.warehouse import Warehouse
from app.schemas.inventory import (
    InventoryCreate,
    InventoryReorderUpdate,
    InventoryStockAdjustment,
)
from app.utils.enums import InventoryTransactionType
from app.services.audit_log_service import create_audit_log


def create_inventory(
    db: Session,
    data: InventoryCreate,
    created_by: int,
) -> Inventory:
    product = db.get(Product, data.product_id)

    if product is None:
        raise HTTPException(
            status_code=404,
            detail="Product not found",
        )

    if not product.is_active:
        raise HTTPException(
            status_code=400,
            detail="Cannot create inventory for an inactive product",
        )

    warehouse = db.get(Warehouse, data.warehouse_id)

    if warehouse is None:
        raise HTTPException(
            status_code=404,
            detail="Warehouse not found",
        )

    if not warehouse.is_active:
        raise HTTPException(
            status_code=400,
            detail="Cannot create inventory for an inactive warehouse",
        )

    existing = db.execute(
        select(Inventory).where(
            Inventory.product_id == data.product_id,
            Inventory.warehouse_id == data.warehouse_id,
        )
    ).scalar_one_or_none()

    if existing is not None:
        raise HTTPException(
            status_code=409,
            detail="Inventory already exists for this product and warehouse",
        )

    inventory = Inventory(
        product_id=data.product_id,
        warehouse_id=data.warehouse_id,
        available_quantity=data.available_quantity,
        reorder_level=data.reorder_level,
    )

    try:
        db.add(inventory)
        db.flush()

        if data.available_quantity > 0:
            db.add(
                InventoryTransaction(
                    inventory_id=inventory.id,
                    transaction_type=InventoryTransactionType.STOCK_IN.value,
                    quantity=data.available_quantity,
                    reference_type="INITIAL_STOCK",
                    reason="Initial inventory stock",
                    created_by=created_by,
                )
            )

        create_audit_log(
            db=db,
            user_id=created_by,
            action="INVENTORY_CREATED",
            entity_type="INVENTORY",
            entity_id=inventory.id,
            description=(
                f"Inventory created for product {data.product_id} "
                f"in warehouse {data.warehouse_id}. "
                f"Initial stock: {data.available_quantity}"
            ),
        )

        db.commit()
        db.refresh(inventory)

        return inventory

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail=(
                "Inventory already exists or violates a database constraint"
            ),
        )
    except Exception:
        db.rollback()
        raise



def list_inventory(
    db: Session,
    warehouse_id: int | None = None,
    skip: int = 0,
    limit: int = 100,
) -> list[Inventory]:
    query = select(Inventory).order_by(Inventory.id)

    if warehouse_id is not None:
        query = query.where(
            Inventory.warehouse_id == warehouse_id
        )

    query = query.offset(skip).limit(limit)

    return list(db.scalars(query).all())


def get_inventory(
    db: Session,
    inventory_id: int,
) -> Inventory:
    inventory = db.get(Inventory, inventory_id)

    if inventory is None:
        raise HTTPException(
            status_code=404,
            detail="Inventory record not found",
        )

    return inventory


def adjust_inventory_stock(
    db: Session,
    inventory_id: int,
    data: InventoryStockAdjustment,
    created_by: int,
    increase: bool = True,
) -> Inventory:
    try:
        inventory = db.scalar(
            select(Inventory)
            .where(Inventory.id == inventory_id)
            .with_for_update()
        )

        if inventory is None:
            raise HTTPException(
                status_code=404,
                detail="Inventory record not found",
            )

        if increase:
            inventory.available_quantity += data.quantity
            transaction_type = InventoryTransactionType.STOCK_IN.value
            action = "INVENTORY_STOCK_IN"
            operation = "increased"

        else:
            if inventory.available_quantity < data.quantity:
                raise HTTPException(
                    status_code=409,
                    detail="Insufficient available stock",
                )

            inventory.available_quantity -= data.quantity
            transaction_type = InventoryTransactionType.STOCK_OUT.value
            action = "INVENTORY_STOCK_OUT"
            operation = "decreased"

        db.add(
            InventoryTransaction(
                inventory_id=inventory.id,
                transaction_type=transaction_type,
                quantity=data.quantity,
                reference_type="MANUAL_ADJUSTMENT",
                reason=data.reason,
                created_by=created_by,
            )
        )

        create_audit_log(
            db=db,
            user_id=created_by,
            action=action,
            entity_type="INVENTORY",
            entity_id=inventory.id,
            description=(
                f"Inventory stock {operation} by {data.quantity}. "
                f"Reason: {data.reason}"
            ),
        )

        db.commit()
        db.refresh(inventory)

        return inventory

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        raise



def update_inventory_reorder_level(
    db: Session,
    inventory_id: int,
    data: InventoryReorderUpdate,
    updated_by: int | None = None,
) -> Inventory:
    try:
        inventory = db.scalar(
            select(Inventory)
            .where(Inventory.id == inventory_id)
            .with_for_update()
        )

        if inventory is None:
            raise HTTPException(
                status_code=404,
                detail="Inventory record not found",
            )

        old_reorder_level = inventory.reorder_level
        inventory.reorder_level = data.reorder_level

        create_audit_log(
            db=db,
            user_id=updated_by,
            action="INVENTORY_REORDER_LEVEL_UPDATED",
            entity_type="INVENTORY",
            entity_id=inventory.id,
            description=(
                f"Reorder level changed from {old_reorder_level} "
                f"to {data.reorder_level}"
            ),
        )

        db.commit()
        db.refresh(inventory)

        return inventory

    except Exception:
        db.rollback()
        raise

