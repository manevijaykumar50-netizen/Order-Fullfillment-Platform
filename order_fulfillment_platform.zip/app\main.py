
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.background.scheduler import start_scheduler, stop_scheduler

from app.routers.auth import router as auth_router
from app.routers.users import router as users_router
from app.routers.categories import router as categories_router
from app.routers.products import router as products_router
from app.routers.warehouses import router as warehouses_router
from app.routers.warehouse_users import router as warehouse_users_router
from app.routers.inventory import router as inventory_router
from app.routers.orders import router as orders_router
from app.routers.returns import router as returns_router
from app.routers.notifications import router as notifications_router
from app.routers.audit_logs import router as audit_logs_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    start_scheduler()
    try:
        yield
    finally:
        stop_scheduler()


app = FastAPI(
    title="Order Fulfillment & Inventory Management Platform",
    version="1.0.0",
    description="Backend API for order fulfillment and inventory management",
    lifespan=lifespan,
)

app.include_router(auth_router)
app.include_router(users_router)
app.include_router(categories_router)
app.include_router(products_router)
app.include_router(warehouses_router)
app.include_router(warehouse_users_router)
app.include_router(inventory_router)
app.include_router(orders_router)
app.include_router(returns_router)
app.include_router(notifications_router)
app.include_router(audit_logs_router)


@app.get("/")
def root():
    return {
        "message": "Order Fulfillment & Inventory Management Platform API"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
