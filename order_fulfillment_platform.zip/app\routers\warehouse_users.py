
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.permissions import require_roles
from app.database import get_db
from app.models.user import User
from app.schemas.warehouse_user import (
    WarehouseUserCreate,
    WarehouseUserResponse,
)
from app.services.warehouse_user_service import (
    create_warehouse_user,
    list_warehouse_users,
)
from app.utils.enums import UserRole


router = APIRouter(
    prefix="/warehouse-users",
    tags=["Warehouse User Assignments"],
)


@router.post(
    "",
    response_model=WarehouseUserResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_warehouse_user_endpoint(
    data: WarehouseUserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return create_warehouse_user(db, data)


@router.get(
    "",
    response_model=list[WarehouseUserResponse],
)
def get_warehouse_users(
    warehouse_id: int | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
        )
    ),
):
    return list_warehouse_users(db, warehouse_id)
