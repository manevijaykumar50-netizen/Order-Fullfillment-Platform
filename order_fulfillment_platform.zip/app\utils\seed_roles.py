from app.database import get_engine
from app.models.role import Role
from sqlalchemy.orm import Session


def seed_roles():
    engine = get_engine()

    roles = [
        "Admin",
        "Warehouse Manager",
        "Fulfillment Agent",
        "Customer",
    ]

    with Session(engine) as db:
        for role_name in roles:
            existing_role = (
                db.query(Role)
                .filter(Role.name == role_name)
                .first()
            )

            if not existing_role:
                db.add(Role(name=role_name))
                print(f"Created role: {role_name}")
            else:
                print(f"Role already exists: {role_name}")

        db.commit()

    print("Role seeding completed successfully.")


if __name__ == "__main__":
    seed_roles()