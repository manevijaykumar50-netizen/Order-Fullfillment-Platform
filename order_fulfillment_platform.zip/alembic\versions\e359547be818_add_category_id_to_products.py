
from alembic import op
import sqlalchemy as sa


revision = "e359547be818"
down_revision = "d5cd94763ec3"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "products",
        sa.Column("category_id", sa.Integer(), nullable=True),
    )

    op.create_index(
        "ix_products_category_id",
        "products",
        ["category_id"],
        unique=False,
    )

    op.create_foreign_key(
        "fk_products_category_id_categories",
        "products",
        "categories",
        ["category_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    op.drop_constraint(
        "fk_products_category_id_categories",
        "products",
        type_="foreignkey",
    )
    op.drop_index("ix_products_category_id", table_name="products")
    op.drop_column("products", "category_id")

