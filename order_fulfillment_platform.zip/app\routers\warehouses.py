
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.permissions import require_roles
from app.database import get_db
from app.models.user import User
from app.schemas.warehouse import (
    WarehouseCreate,
    WarehouseResponse,
    WarehouseStatusUpdate,
    WarehouseUpdate,
)
from app.services.warehouse_service import (
    create_warehouse,
    get_warehouse,
    list_warehouses,
    update_warehouse,
    update_warehouse_status,
)
from app.utils.enums import UserRole


router = APIRouter(
    prefix="/warehouses",
    tags=["Warehouses"],
)


@router.post(
    "",
    response_model=WarehouseResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_warehouse_endpoint(
    data: WarehouseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return create_warehouse(db, data)


@router.get(
    "",
    response_model=list[WarehouseResponse],
)
def get_warehouses(
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
            UserRole.CUSTOMER,
        )
    ),
):
    return list_warehouses(db)


@router.get(
    "/{warehouse_id}",
    response_model=WarehouseResponse,
)
def get_warehouse_by_id(
    warehouse_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
            UserRole.CUSTOMER,
        )
    ),
):
    return get_warehouse(db, warehouse_id)


@router.patch(
    "/{warehouse_id}",
    response_model=WarehouseResponse,
)
def update_warehouse_endpoint(
    warehouse_id: int,
    data: WarehouseUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return update_warehouse(db, warehouse_id, data)


@router.patch(
    "/{warehouse_id}/status",
    response_model=WarehouseResponse,
)
def update_warehouse_status_endpoint(
    warehouse_id: int,
    data: WarehouseStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return update_warehouse_status(
        db,
        warehouse_id,
        data,
    )