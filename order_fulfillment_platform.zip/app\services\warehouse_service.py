
from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.models.warehouse import Warehouse
from app.schemas.warehouse import (
    WarehouseCreate,
    WarehouseUpdate,
    WarehouseStatusUpdate,
)


def create_warehouse(db: Session, data: WarehouseCreate) -> Warehouse:
    existing = (
        db.query(Warehouse)
        .filter(
            or_(
                Warehouse.name == data.name,
                Warehouse.code == data.code,
            )
        )
        .first()
    )

    if existing:
        if existing.name == data.name:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A warehouse with this name already exists",
            )

        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A warehouse with this code already exists",
        )

    warehouse = Warehouse(**data.model_dump())

    db.add(warehouse)
    db.commit()
    db.refresh(warehouse)

    return warehouse


def list_warehouses(db: Session) -> list[Warehouse]:
    return db.query(Warehouse).order_by(Warehouse.id).all()


def get_warehouse(db: Session, warehouse_id: int) -> Warehouse:
    warehouse = (
        db.query(Warehouse)
        .filter(Warehouse.id == warehouse_id)
        .first()
    )

    if warehouse is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Warehouse not found",
        )

    return warehouse


def update_warehouse(
    db: Session,
    warehouse_id: int,
    data: WarehouseUpdate,
) -> Warehouse:
    warehouse = get_warehouse(db, warehouse_id)
    updates = data.model_dump(exclude_unset=True)

    for field in ("name", "code"):
        value = updates.get(field)

        if value is not None:
            duplicate = (
                db.query(Warehouse)
                .filter(
                    getattr(Warehouse, field) == value,
                    Warehouse.id != warehouse_id,
                )
                .first()
            )

            if duplicate:
                message = (
                    f"A warehouse with this {field} already exists"
                )
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=message,
                )

    for field, value in updates.items():
        setattr(warehouse, field, value)

    db.commit()
    db.refresh(warehouse)

    return warehouse


def update_warehouse_status(
    db: Session,
    warehouse_id: int,
    data: WarehouseStatusUpdate,
) -> Warehouse:
    warehouse = get_warehouse(db, warehouse_id)

    warehouse.is_active = data.is_active

    db.commit()
    db.refresh(warehouse)

    return warehouse