from datetime import datetime, timezone
import hashlib

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.security import (
    create_access_token,
    create_refresh_token,
    hash_password,
    verify_password,
    decode_token,
)
from app.models.refresh_token import RefreshToken
from app.models.role import Role
from app.models.user import User
from app.schemas.auth import (
    ChangePasswordRequest,
    LoginRequest,
    RegisterRequest,
)
from app.utils.enums import UserRole


def _hash_refresh_token(token: str) -> str:
    """Store only a hash of the refresh token in the database."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _get_customer_role(db: Session) -> Role:
    """Get the default Customer role for new registrations."""

    role = (
        db.query(Role)
        .filter(Role.name == UserRole.CUSTOMER.value)
        .first()
    )

    if role is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Customer role is not configured",
        )

    return role


def register_user(
    data: RegisterRequest,
    db: Session,
) -> User:
    """Register a new customer."""

    existing_user = (
        db.query(User)
        .filter(User.email == data.email.lower())
        .first()
    )

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email already registered",
        )

    role = _get_customer_role(db)

    user = User(
        full_name=data.full_name,
        email=data.email.lower(),
        password_hash=hash_password(data.password),
        role_id=role.id,
        is_active=True,
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return user


def login_user(
    data: LoginRequest,
    db: Session,
) -> tuple[str, str]:
    """Authenticate a user and create access and refresh tokens."""

    user = (
        db.query(User)
        .filter(User.email == data.email.lower())
        .first()
    )

    if user is None or not verify_password(
        data.password,
        user.password_hash,
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    access_token = create_access_token(user.id)
    refresh_token = create_refresh_token(user.id)

    refresh_token_record = RefreshToken(
        user_id=user.id,
        token_hash=_hash_refresh_token(refresh_token),
        expires_at=datetime.now(timezone.utc).replace(
            microsecond=0
        ),
    )

    # The actual expiry will be assigned by the refresh-token
    # service when token rotation is implemented.
    from datetime import timedelta
    from app.config import settings

    refresh_token_record.expires_at = (
        datetime.now(timezone.utc)
        + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    )

    db.add(refresh_token_record)
    db.commit()

    return access_token, refresh_token


def refresh_access_token(
    refresh_token: str,
    db: Session,
) -> tuple[str, str]:
    """
    Rotate a refresh token and issue a new access/refresh token pair.
    """

    try:
        payload = decode_token(refresh_token)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
        )

    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token required",
        )

    user_id = payload.get("sub")

    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )

    try:
        user_id = int(user_id)
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user ID in refresh token",
        )

    token_hash = _hash_refresh_token(refresh_token)

    stored_token = (
        db.query(RefreshToken)
        .filter(
            RefreshToken.token_hash == token_hash,
            RefreshToken.user_id == user_id,
        )
        .first()
    )

    if stored_token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token not found",
        )

    if stored_token.is_revoked:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has been revoked",
        )

    now = datetime.now(timezone.utc)

    if stored_token.expires_at <= now:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has expired",
        )

    user = db.query(User).filter(User.id == user_id).first()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    # Revoke the old refresh token.
    stored_token.is_revoked = True
    stored_token.revoked_at = now

    # Create a new token pair.
    new_access_token = create_access_token(user.id)
    new_refresh_token = create_refresh_token(user.id)

    from datetime import timedelta
    from app.config import settings

    new_refresh_record = RefreshToken(
        user_id=user.id,
        token_hash=_hash_refresh_token(new_refresh_token),
        expires_at=(
            now
            + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
        ),
    )

    db.add(new_refresh_record)
    db.commit()

    return new_access_token, new_refresh_token


def logout_user(
    refresh_token: str,
    db: Session,
) -> None:
    """Revoke a refresh token."""

    token_hash = _hash_refresh_token(refresh_token)

    stored_token = (
        db.query(RefreshToken)
        .filter(RefreshToken.token_hash == token_hash)
        .first()
    )

    if stored_token is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Refresh token not found",
        )

    if not stored_token.is_revoked:
        stored_token.is_revoked = True
        stored_token.revoked_at = datetime.now(timezone.utc)
        db.commit()


def change_password(
    user: User,
    data: ChangePasswordRequest,
    db: Session,
) -> None:
    """Change the authenticated user's password."""

    if not verify_password(
        data.current_password,
        user.password_hash,
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect",
        )

    if data.current_password == data.new_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must be different",
        )

    user.password_hash = hash_password(data.new_password)

    # Revoke all existing refresh tokens after password change.
    now = datetime.now(timezone.utc)

    (
        db.query(RefreshToken)
        .filter(
            RefreshToken.user_id == user.id,
            RefreshToken.is_revoked.is_(False),
        )
        .update(
            {
                RefreshToken.is_revoked: True,
                RefreshToken.revoked_at: now,
            },
            synchronize_session=False,
        )
    )

    db.commit()