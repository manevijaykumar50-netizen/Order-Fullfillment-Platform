
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.category import Category
from app.models.product import Product
from app.schemas.product import ProductCreate, ProductUpdate


def _get_category(
    db: Session,
    category_id: int,
    require_active: bool = True,
) -> Category:
    category = (
        db.query(Category)
        .filter(Category.id == category_id)
        .first()
    )

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )

    if require_active and not category.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot use an inactive category",
        )

    return category


def create_product(
    db: Session,
    data: ProductCreate,
) -> Product:
    existing_product = (
        db.query(Product)
        .filter(Product.sku == data.sku)
        .first()
    )

    if existing_product:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A product with this SKU already exists",
        )

    _get_category(db, data.category_id)

    product = Product(
        sku=data.sku,
        name=data.name,
        description=data.description,
        price=data.price,
        category_id=data.category_id,
        is_active=True,
    )

    db.add(product)
    db.commit()
    db.refresh(product)

    return product


def list_products(db: Session) -> list[Product]:
    return db.query(Product).order_by(Product.id).all()


def get_product(db: Session, product_id: int) -> Product:
    product = (
        db.query(Product)
        .filter(Product.id == product_id)
        .first()
    )

    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    return product


def update_product(
    db: Session,
    product_id: int,
    data: ProductUpdate,
) -> Product:
    product = get_product(db, product_id)
    updates = data.model_dump(exclude_unset=True)

    if "sku" in updates and updates["sku"] is not None:
        existing_product = (
            db.query(Product)
            .filter(
                Product.sku == updates["sku"],
                Product.id != product_id,
            )
            .first()
        )

        if existing_product:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A product with this SKU already exists",
            )

    if "category_id" in updates and updates["category_id"] is not None:
        _get_category(db, updates["category_id"])

    for field, value in updates.items():
        setattr(product, field, value)

    db.commit()
    db.refresh(product)

    return product


def update_product_status(
    db: Session,
    product_id: int,
    is_active: bool,
) -> Product:
    product = get_product(db, product_id)
    product.is_active = is_active

    db.commit()
    db.refresh(product)

    return product