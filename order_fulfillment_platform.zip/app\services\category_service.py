from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.category import Category
from app.schemas.category import (
    CategoryCreate,
    CategoryUpdate,
    CategoryStatusUpdate,
)


def create_category(
    db: Session,
    data: CategoryCreate,
) -> Category:
    existing_category = (
        db.query(Category)
        .filter(Category.name == data.name)
        .first()
    )

    if existing_category:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A category with this name already exists",
        )

    category = Category(
        name=data.name,
        description=data.description,
        is_active=True,
    )

    db.add(category)
    db.commit()
    db.refresh(category)

    return category


def list_categories(
    db: Session,
) -> list[Category]:
    return (
        db.query(Category)
        .order_by(Category.id)
        .all()
    )


def get_category(
    db: Session,
    category_id: int,
) -> Category:
    category = (
        db.query(Category)
        .filter(Category.id == category_id)
        .first()
    )

    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )

    return category


def update_category(
    db: Session,
    category_id: int,
    data: CategoryUpdate,
) -> Category:
    category = get_category(db, category_id)

    if data.name is not None:
        existing_category = (
            db.query(Category)
            .filter(
                Category.name == data.name,
                Category.id != category_id,
            )
            .first()
        )

        if existing_category:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A category with this name already exists",
            )

        category.name = data.name

    if data.description is not None:
        category.description = data.description

    db.commit()
    db.refresh(category)

    return category


def update_category_status(
    db: Session,
    category_id: int,
    data: CategoryStatusUpdate,
) -> Category:
    category = get_category(db, category_id)

    category.is_active = data.is_active

    db.commit()
    db.refresh(category)

    return category