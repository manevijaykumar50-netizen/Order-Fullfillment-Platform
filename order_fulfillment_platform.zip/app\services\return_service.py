
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.inventory import Inventory
from app.models.inventory_transaction import InventoryTransaction
from app.models.order import Order
from app.models.order_history import OrderStatusHistory
from app.models.order_item import OrderItem
from app.models.return_item import ReturnItem
from app.models.return_model import Return
from app.schemas.return_schema import ReturnCreate, ReturnStatusUpdate
from app.utils.enums import (
    InventoryTransactionType,
    OrderStatus,
    PaymentStatus,
    ReturnStatus,
)


def request_return(
    db: Session,
    data: ReturnCreate,
    customer_id: int,
) -> Return:
    try:
        order = db.scalar(
            select(Order)
            .where(Order.id == data.order_id)
            .with_for_update()
        )

        if order is None:
            raise HTTPException(404, "Order not found")

        if order.customer_id != customer_id:
            raise HTTPException(403, "You cannot return another customer's order")

        latest_history = db.scalar(
            select(OrderStatusHistory)
            .where(OrderStatusHistory.order_id == order.id)
            .order_by(
                OrderStatusHistory.created_at.desc(),
                OrderStatusHistory.id.desc(),
            )
            .limit(1)
        )

        if (
            latest_history is None
            or latest_history.new_status != OrderStatus.DELIVERED.value
        ):
            raise HTTPException(400, "Only delivered orders can be returned")

        if order.payment_status == PaymentStatus.REFUNDED.value:
            raise HTTPException(400, "This order has already been refunded")

        requested = {}

        for item in data.items:
            requested[item.product_id] = (
                requested.get(item.product_id, 0) + item.quantity
            )

        order_items = db.scalars(
            select(OrderItem).where(OrderItem.order_id == order.id)
        ).all()

        order_item_map = {
            item.product_id: item for item in order_items
        }

        if not set(requested).issubset(order_item_map):
            raise HTTPException(
                400,
                "One or more products do not belong to this order",
            )

        existing_returns = db.scalars(
            select(Return).where(
                Return.order_id == order.id,
                Return.status.in_([
                    ReturnStatus.REQUESTED.value,
                    ReturnStatus.APPROVED.value,
                    ReturnStatus.RECEIVED.value,
                    ReturnStatus.REFUNDED.value,
                ]),
            )
        ).all()

        already_returned = {}

        for existing in existing_returns:
            existing_items = db.scalars(
                select(ReturnItem).where(
                    ReturnItem.return_id == existing.id
                )
            ).all()

            for item in existing_items:
                already_returned[item.product_id] = (
                    already_returned.get(item.product_id, 0)
                    + item.quantity
                )

        total_refund = Decimal("0.00")
        prepared_items = []

        for product_id, quantity in requested.items():
            order_item = order_item_map[product_id]
            remaining = (
                order_item.quantity
                - already_returned.get(product_id, 0)
            )

            if quantity > remaining:
                raise HTTPException(
                    400,
                    f"Return quantity exceeds remaining purchased quantity for product {product_id}",
                )

            unit_price = Decimal(str(order_item.unit_price))
            total_refund += unit_price * quantity

            prepared_items.append({
                "product_id": product_id,
                "quantity": quantity,
                "unit_price": unit_price,
            })

        return_record = Return(
            order_id=order.id,
            customer_id=customer_id,
            reason=data.reason,
            status=ReturnStatus.REQUESTED.value,
            refund_amount=total_refund.quantize(Decimal("0.01")),
        )

        db.add(return_record)
        db.flush()

        for item in prepared_items:
            db.add(
                ReturnItem(
                    return_id=return_record.id,
                    product_id=item["product_id"],
                    quantity=item["quantity"],
                    unit_price=item["unit_price"],
                )
            )

        db.commit()
        db.refresh(return_record)
        return return_record

    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise


def get_return(
    db: Session,
    return_id: int,
    user_id: int,
    allow_staff: bool = False,
) -> Return:
    record = db.get(Return, return_id)

    if record is None:
        raise HTTPException(404, "Return not found")

    if not allow_staff and record.customer_id != user_id:
        raise HTTPException(403, "You cannot access this return")

    return record


def update_return_status(
    db: Session,
    return_id: int,
    data: ReturnStatusUpdate,
    changed_by: int,
) -> Return:
    try:
        record = db.scalar(
            select(Return)
            .where(Return.id == return_id)
            .with_for_update()
        )

        if record is None:
            raise HTTPException(404, "Return not found")

        order = db.scalar(
            select(Order)
            .where(Order.id == record.order_id)
            .with_for_update()
        )

        new_status = data.status.value
        old_status = record.status

        allowed_transitions = {
            ReturnStatus.REQUESTED.value: {
                ReturnStatus.APPROVED.value,
                ReturnStatus.REJECTED.value,
            },
            ReturnStatus.APPROVED.value: {
                ReturnStatus.RECEIVED.value,
            },
            ReturnStatus.RECEIVED.value: {
                ReturnStatus.REFUNDED.value,
            },
        }

        if new_status not in allowed_transitions.get(old_status, set()):
            raise HTTPException(
                400,
                f"Cannot change return status from {old_status} to {new_status}",
            )

        if new_status == ReturnStatus.RECEIVED.value:
            return_items = db.scalars(
                select(ReturnItem).where(
                    ReturnItem.return_id == record.id
                )
            ).all()

            for item in return_items:
                inventory = db.scalar(
                    select(Inventory)
                    .where(
                        Inventory.product_id == item.product_id,
                        Inventory.warehouse_id == order.warehouse_id,
                    )
                    .with_for_update()
                )

                if inventory is None:
                    raise HTTPException(
                        409,
                        f"Inventory not found for product {item.product_id}",
                    )

                inventory.available_quantity += item.quantity

                db.add(
                    InventoryTransaction(
                        inventory_id=inventory.id,
                        transaction_type=InventoryTransactionType.STOCK_IN.value,
                        quantity=item.quantity,
                        reference_type="RETURN",
                        reference_id=record.id,
                        reason="Returned products received",
                        created_by=changed_by,
                    )
                )

        if new_status == ReturnStatus.REFUNDED.value:
            order.payment_status = PaymentStatus.REFUNDED.value

        record.status = new_status

        db.commit()
        db.refresh(record)
        return record

    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise
