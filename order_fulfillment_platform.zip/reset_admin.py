from sqlalchemy.orm import Session

from app.database import get_engine
from app.models.user import User
from app.core.security import hash_password

db = Session(get_engine())

user = db.query(User).filter(
    User.email == "admin@example.com"
).first()

if user is None:
    print("Admin user not found")
else:
    user.password_hash = hash_password("Admin@123")
    db.commit()
    print("Admin password reset successfully")

db.close()