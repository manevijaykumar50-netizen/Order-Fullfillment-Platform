
from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.dependencies import get_current_user
from app.core.permissions import require_roles
from app.database import get_db
from app.models.order import Order
from app.models.order_history import OrderStatusHistory
from app.models.user import User
from app.schemas.order import OrderCreate, OrderResponse
from app.schemas.order_processing import (
    OrderAssignmentCreate,
    OrderAssignmentResponse,
    OrderStatusUpdate,
)
from app.services.order_service import create_order
from app.services.order_processing_service import (
    assign_order,
    update_order_status,
)
from app.utils.enums import UserRole

router = APIRouter(prefix="/orders", tags=["Orders"])


@router.post(
    "",
    response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED,
)
def place_order(
    data: OrderCreate,
    idempotency_key: str = Header(
        ...,
        alias="Idempotency-Key",
        min_length=1,
        max_length=255,
    ),
    current_user: User = Depends(require_roles(UserRole.CUSTOMER)),
    db: Session = Depends(get_db),
):
    """Create an order and reserve the required inventory."""
    return create_order(
        db=db,
        data=data,
        customer_id=current_user.id,
        idempotency_key=idempotency_key,
    )


@router.get("/{order_id}", response_model=OrderResponse)
def get_order(
    order_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Retrieve an order with role-based access checks."""
    order = db.scalar(
        select(Order)
        .options(selectinload(Order.items))
        .where(Order.id == order_id)
    )

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    role_name = current_user.role.name if current_user.role else None

    if (
        role_name == UserRole.CUSTOMER.value
        and order.customer_id != current_user.id
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You cannot access another customer's order",
        )

    if role_name not in {
        UserRole.CUSTOMER.value,
        UserRole.ADMIN.value,
        UserRole.WAREHOUSE_MANAGER.value,
        UserRole.FULFILLMENT_AGENT.value,
    }:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to view this order",
        )

    return order


@router.post(
    "/{order_id}/assignment",
    response_model=OrderAssignmentResponse,
    status_code=status.HTTP_200_OK,
)
def assign_order_endpoint(
    order_id: int,
    data: OrderAssignmentCreate,
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
        )
    ),
    db: Session = Depends(get_db),
):
    """Assign an order to an eligible fulfillment agent."""
    return assign_order(
        db=db,
        order_id=order_id,
        data=data,
        assigned_by=current_user.id,
    )


@router.patch("/{order_id}/status")
def update_order_status_endpoint(
    order_id: int,
    data: OrderStatusUpdate,
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
        )
    ),
    db: Session = Depends(get_db),
):
    """Update order status and record its history."""
    history = update_order_status(
        db=db,
        order_id=order_id,
        data=data,
        changed_by=current_user.id,
    )

    return {
        "id": history.id,
        "order_id": history.order_id,
        "old_status": history.old_status,
        "new_status": history.new_status,
        "changed_by": history.changed_by,
        "reason": history.reason,
        "created_at": history.created_at,
    }


@router.get("/{order_id}/history")
def get_order_status_history(
    order_id: int,
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
        )
    ),
    db: Session = Depends(get_db),
):
    """List status history for an order."""
    order = db.get(Order, order_id)

    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    histories = db.scalars(
        select(OrderStatusHistory)
        .where(OrderStatusHistory.order_id == order_id)
        .order_by(
            OrderStatusHistory.created_at.asc(),
            OrderStatusHistory.id.asc(),
        )
    ).all()

    return [
        {
            "id": entry.id,
            "order_id": entry.order_id,
            "old_status": entry.old_status,
            "new_status": entry.new_status,
            "changed_by": entry.changed_by,
            "reason": entry.reason,
            "created_at": entry.created_at,
        }
        for entry in histories
    ]
