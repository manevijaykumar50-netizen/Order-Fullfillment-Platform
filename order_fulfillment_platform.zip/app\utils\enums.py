from enum import Enum


class UserRole(str, Enum):
    ADMIN = "Admin"
    WAREHOUSE_MANAGER = "Warehouse Manager"
    FULFILLMENT_AGENT = "Fulfillment Agent"
    CUSTOMER = "Customer"


class OrderStatus(str, Enum):
    PENDING = "Pending"
    CONFIRMED = "Confirmed"
    PROCESSING = "Processing"
    PACKED = "Packed"
    SHIPPED = "Shipped"
    DELIVERED = "Delivered"
    CANCELLED = "Cancelled"
    FAILED = "Failed"
    RETURNED = "Returned"


class PaymentStatus(str, Enum):
    PENDING = "Pending"
    PAID = "Paid"
    FAILED = "Failed"
    REFUNDED = "Refunded"


class ReturnStatus(str, Enum):
    REQUESTED = "Requested"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    RECEIVED = "Received"
    REFUNDED = "Refunded"


class InventoryTransactionType(str, Enum):
    STOCK_IN = "STOCK_IN"
    STOCK_OUT = "STOCK_OUT"
    RESERVATION = "RESERVATION"
    RELEASE = "RELEASE"
    DAMAGE = "DAMAGE"
    ADJUSTMENT = "ADJUSTMENT"
    TRANSFER_OUT = "TRANSFER_OUT"
    TRANSFER_IN = "TRANSFER_IN"
    
    # Add the function here
def is_valid_inventory_transaction_type(value: str) -> bool:
    return value in {item.value for item in InventoryTransactionType}
    