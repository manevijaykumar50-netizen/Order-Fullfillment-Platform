
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user
from app.core.permissions import require_roles
from app.database import get_db
from app.models.return_item import ReturnItem
from app.models.return_model import Return
from app.models.user import User
from app.schemas.return_schema import (
    ReturnCreate,
    ReturnResponse,
    ReturnStatusUpdate,
)
from app.services.return_service import (
    get_return,
    request_return,
    update_return_status,
)
from app.utils.enums import UserRole

router = APIRouter(prefix="/returns", tags=["Returns"])


@router.post("", response_model=ReturnResponse, status_code=201)
def create_return(
    data: ReturnCreate,
    current_user: User = Depends(require_roles(UserRole.CUSTOMER)),
    db: Session = Depends(get_db),
):
    record = request_return(
        db=db,
        data=data,
        customer_id=current_user.id,
    )

    record.items = db.scalars(
        select(ReturnItem).where(ReturnItem.return_id == record.id)
    ).all()

    return record


@router.get("", response_model=list[ReturnResponse])
def list_returns(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    role_name = current_user.role.name if current_user.role else None

    query = select(Return).order_by(Return.requested_at.desc())

    if role_name == UserRole.CUSTOMER.value:
        query = query.where(Return.customer_id == current_user.id)
    elif role_name not in {
        UserRole.ADMIN.value,
        UserRole.WAREHOUSE_MANAGER.value,
    }:
        raise HTTPException(403, "You cannot view returns")

    records = db.scalars(query).all()

    for record in records:
        record.items = db.scalars(
            select(ReturnItem).where(ReturnItem.return_id == record.id)
        ).all()

    return records


@router.get("/{return_id}", response_model=ReturnResponse)
def retrieve_return(
    return_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    role_name = current_user.role.name if current_user.role else None

    is_staff = role_name in {
        UserRole.ADMIN.value,
        UserRole.WAREHOUSE_MANAGER.value,
    }

    record = get_return(
        db=db,
        return_id=return_id,
        user_id=current_user.id,
        allow_staff=is_staff,
    )

    record.items = db.scalars(
        select(ReturnItem).where(ReturnItem.return_id == record.id)
    ).all()

    return record


@router.patch("/{return_id}/status", response_model=ReturnResponse)
def change_return_status(
    return_id: int,
    data: ReturnStatusUpdate,
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
        )
    ),
    db: Session = Depends(get_db),
):
    record = update_return_status(
        db=db,
        return_id=return_id,
        data=data,
        changed_by=current_user.id,
    )

    record.items = db.scalars(
        select(ReturnItem).where(ReturnItem.return_id == record.id)
    ).all()

    return record
