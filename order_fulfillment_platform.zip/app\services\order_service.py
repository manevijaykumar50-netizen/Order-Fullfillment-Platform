
import json
import secrets
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.models.idempotency import IdempotencyKey
from app.models.inventory import Inventory
from app.models.inventory_transaction import InventoryTransaction
from app.models.order import Order
from app.models.order_history import OrderStatusHistory
from app.models.order_item import OrderItem
from app.models.product import Product
from app.models.warehouse import Warehouse
from app.schemas.order import OrderCreate
from app.utils.enums import (
    InventoryTransactionType,
    OrderStatus,
    PaymentStatus,
)


def create_order(
    db: Session,
    data: OrderCreate,
    customer_id: int,
    idempotency_key: str,
) -> Order:
    operation = "CREATE_ORDER"

    if not idempotency_key.strip():
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key header is required",
        )

    try:
        # Check whether this key has already been used.
        previous = db.scalar(
            select(IdempotencyKey).where(
                IdempotencyKey.key == idempotency_key
            )
        )

        if previous is not None:
            if (
                previous.user_id != customer_id
                or previous.operation != operation
            ):
                raise HTTPException(
                    status_code=409,
                    detail="Idempotency key has already been used",
                )

            if previous.resource_id is not None:
                order = db.scalar(
                    select(Order)
                    .options(selectinload(Order.items))
                    .where(Order.id == previous.resource_id)
                )

                if order is not None:
                    db.rollback()
                    return order

            raise HTTPException(
                status_code=409,
                detail="Idempotency key cannot be reused",
            )

        # Validate warehouse.
        warehouse = db.get(Warehouse, data.warehouse_id)

        if warehouse is None:
            raise HTTPException(404, "Warehouse not found")

        if not warehouse.is_active:
            raise HTTPException(400, "Warehouse is inactive")

        # Combine duplicate product IDs.
        requested: dict[int, int] = {}

        for item in data.items:
            requested[item.product_id] = (
                requested.get(item.product_id, 0) + item.quantity
            )

        product_ids = sorted(requested)

        products = db.scalars(
            select(Product)
            .where(Product.id.in_(product_ids))
            .order_by(Product.id)
        ).all()

        product_by_id = {
            product.id: product for product in products
        }

        if len(product_by_id) != len(product_ids):
            raise HTTPException(
                404,
                "One or more products were not found",
            )

        for product in products:
            if not product.is_active:
                raise HTTPException(
                    400,
                    f"Product {product.id} is inactive",
                )

        # Lock inventory rows to prevent concurrent overselling.
        inventory_rows = db.scalars(
            select(Inventory)
            .where(
                Inventory.warehouse_id == data.warehouse_id,
                Inventory.product_id.in_(product_ids),
            )
            .order_by(Inventory.product_id)
            .with_for_update()
        ).all()

        inventory_by_product = {
            row.product_id: row for row in inventory_rows
        }

        if len(inventory_by_product) != len(product_ids):
            raise HTTPException(
                409,
                "Inventory is not configured for every requested product",
            )

        # Validate all requested quantities before changing stock.
        for product_id, quantity in requested.items():
            inventory = inventory_by_product[product_id]

            if inventory.available_quantity < quantity:
                raise HTTPException(
                    409,
                    f"Insufficient stock for product {product_id}",
                )

        # Calculate order totals using database product prices.
        total = Decimal("0.00")
        prepared_items = []

        for product_id, quantity in requested.items():
            product = product_by_id[product_id]
            unit_price = Decimal(str(product.price))
            subtotal = (unit_price * quantity).quantize(
                Decimal("0.01")
            )

            total += subtotal

            prepared_items.append(
                {
                    "product_id": product_id,
                    "quantity": quantity,
                    "unit_price": unit_price,
                    "subtotal": subtotal,
                }
            )

        # Create the order.
        order = Order(
            order_number=f"ORD-{secrets.token_hex(6).upper()}",
            customer_id=customer_id,
            warehouse_id=data.warehouse_id,
            total_amount=total,
            payment_status=PaymentStatus.PENDING.value,
        )

        db.add(order)
        db.flush()

        # Create order items and reserve inventory.
        for item in prepared_items:
            db.add(
                OrderItem(
                    order_id=order.id,
                    product_id=item["product_id"],
                    quantity=item["quantity"],
                    unit_price=item["unit_price"],
                    subtotal=item["subtotal"],
                )
            )

            inventory = inventory_by_product[item["product_id"]]
            quantity = item["quantity"]

            inventory.available_quantity -= quantity
            inventory.reserved_quantity += quantity

            db.add(
                InventoryTransaction(
                    inventory_id=inventory.id,
                    transaction_type=(
                        InventoryTransactionType.RESERVATION.value
                    ),
                    quantity=quantity,
                    reference_type="ORDER",
                    reference_id=order.id,
                    reason="Inventory reserved for new order",
                    created_by=customer_id,
                )
            )

        # Record the initial order status.
        db.add(
            OrderStatusHistory(
                order_id=order.id,
                old_status=None,
                new_status=OrderStatus.PENDING.value,
                changed_by=customer_id,
                reason="Order created",
            )
        )

        # Save the idempotency key in the same transaction.
        db.add(
            IdempotencyKey(
                key=idempotency_key,
                user_id=customer_id,
                operation=operation,
                resource_type="ORDER",
                resource_id=order.id,
                response_status=201,
                response_body=json.dumps(
                    {
                        "order_id": order.id,
                        "order_number": order.order_number,
                    }
                ),
            )
        )

        db.commit()

        # Reload the order including its items.
        return db.scalar(
            select(Order)
            .options(selectinload(Order.items))
            .where(Order.id == order.id)
        )

    except HTTPException:
        db.rollback()
        raise

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail=(
                "Order could not be created; check stock or "
                "idempotency key"
            ),
        )

    except Exception:
        db.rollback()
        raise
