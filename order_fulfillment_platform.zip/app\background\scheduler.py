from apscheduler.schedulers.background import BackgroundScheduler

from app.background.inventory_jobs import check_low_stock


scheduler = BackgroundScheduler()


def start_scheduler():
    if not scheduler.running:
        scheduler.add_job(
            check_low_stock,
            trigger="interval",
            minutes=30,
            id="low_stock_check",
            replace_existing=True,
            max_instances=1,
        )

        scheduler.start()


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)