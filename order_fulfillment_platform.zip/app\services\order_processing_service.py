
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.order import Order
from app.models.order_assignment import OrderAssignment
from app.models.order_history import OrderStatusHistory
from app.models.user import User
from app.models.warehouse import Warehouse
from app.models.warehouse_user import WarehouseUser
from app.models.inventory import Inventory
from app.models.inventory_transaction import InventoryTransaction
from app.models.order_item import OrderItem

from app.services.audit_log_service import create_audit_log
from app.services.notification_service import create_notification

from app.schemas.order_processing import (
    OrderAssignmentCreate,
    OrderStatusUpdate,
)

from app.utils.enums import InventoryTransactionType, UserRole


def assign_order(
    db: Session,
    order_id: int,
    data: OrderAssignmentCreate,
    assigned_by: int,
) -> OrderAssignment:
    try:
        order = db.scalar(
            select(Order)
            .where(Order.id == order_id)
            .with_for_update()
        )

        if order is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Order not found",
            )

        latest_history = db.scalar(
            select(OrderStatusHistory)
            .where(OrderStatusHistory.order_id == order_id)
            .order_by(
                OrderStatusHistory.created_at.desc(),
                OrderStatusHistory.id.desc(),
            )
            .limit(1)
        )

        if latest_history is None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Order status history is missing",
            )

        if latest_history.new_status in {
            "Cancelled",
            "Delivered",
            "Returned",
            "Failed",
        }:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot assign an order in its current status",
            )

        warehouse = db.get(Warehouse, order.warehouse_id)

        if warehouse is None or not warehouse.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Order warehouse is not active",
            )

        agent = db.get(User, data.fulfillment_agent_id)

        if agent is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Fulfillment agent not found",
            )

        if not agent.is_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot assign an inactive user",
            )

        if (
            agent.role is None
            or agent.role.name != UserRole.FULFILLMENT_AGENT.value
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User must have the Fulfillment Agent role",
            )

        warehouse_assignment = db.scalar(
            select(WarehouseUser).where(
                WarehouseUser.warehouse_id == order.warehouse_id,
                WarehouseUser.user_id == agent.id,
                WarehouseUser.assignment_role
                == UserRole.FULFILLMENT_AGENT.value,
            )
        )

        if warehouse_assignment is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Fulfillment agent is not assigned to this warehouse",
            )

        assignment = db.scalar(
            select(OrderAssignment)
            .where(OrderAssignment.order_id == order_id)
            .with_for_update()
        )

        if assignment is None:
            assignment = OrderAssignment(
                order_id=order_id,
                fulfillment_agent_id=agent.id,
                assigned_by=assigned_by,
                status="Assigned",
            )
            db.add(assignment)
        else:
            assignment.fulfillment_agent_id = agent.id
            assignment.assigned_by = assigned_by
            assignment.status = "Assigned"

        # Create notification for the fulfillment agent.
        create_notification(
            db=db,
            user_id=agent.id,
            title="New Order Assigned",
            message=(
                f"Order {order.order_number} has been assigned to you."
            ),
            notification_type="ORDER",
        )

        # Record order assignment in audit logs.
        create_audit_log(
            db=db,
            user_id=assigned_by,
            action="ORDER_ASSIGNED",
            entity_type="ORDER",
            entity_id=order_id,
            description=(
                f"Order assigned to fulfillment agent {agent.id}"
            ),
        )

        db.commit()
        db.refresh(assignment)

        return assignment

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        raise


def update_order_status(
    db: Session,
    order_id: int,
    data: OrderStatusUpdate,
    changed_by: int,
) -> OrderStatusHistory:
    try:
        order = db.scalar(
            select(Order)
            .where(Order.id == order_id)
            .with_for_update()
        )

        if order is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Order not found",
            )

        assignment = db.scalar(
            select(OrderAssignment).where(
                OrderAssignment.order_id == order_id
            )
        )

        if assignment is None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Assign a fulfillment agent before updating order status",
            )

        latest = db.scalar(
            select(OrderStatusHistory)
            .where(OrderStatusHistory.order_id == order_id)
            .order_by(
                OrderStatusHistory.created_at.desc(),
                OrderStatusHistory.id.desc(),
            )
            .limit(1)
        )

        if latest is None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Order status history is missing",
            )

        old_status = latest.new_status
        new_status = data.status.value

        allowed_transitions = {
            "Pending": {"Confirmed", "Cancelled"},
            "Confirmed": {"Processing", "Cancelled"},
            "Processing": {"Packed", "Failed"},
            "Packed": {"Shipped"},
            "Shipped": {"Delivered", "Failed"},
            "Delivered": {"Returned"},
            "Cancelled": set(),
            "Failed": set(),
            "Returned": set(),
        }

        if new_status not in allowed_transitions.get(old_status, set()):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Cannot change order status from "
                    f"{old_status} to {new_status}"
                ),
            )

        # Release reserved stock if the order is cancelled.
        if new_status == "Cancelled":
            items = db.scalars(
                select(OrderItem)
                .where(OrderItem.order_id == order_id)
                .order_by(OrderItem.product_id)
            ).all()

            for item in items:
                inventory = db.scalar(
                    select(Inventory)
                    .where(
                        Inventory.product_id == item.product_id,
                        Inventory.warehouse_id == order.warehouse_id,
                    )
                    .with_for_update()
                )

                if inventory is None:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Inventory record missing for product "
                            f"{item.product_id}"
                        ),
                    )

                if inventory.reserved_quantity < item.quantity:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Insufficient reserved stock for product "
                            f"{item.product_id}"
                        ),
                    )

                inventory.reserved_quantity -= item.quantity
                inventory.available_quantity += item.quantity

                db.add(
                    InventoryTransaction(
                        inventory_id=inventory.id,
                        transaction_type=(
                            InventoryTransactionType.RELEASE.value
                        ),
                        quantity=item.quantity,
                        reference_type="ORDER",
                        reference_id=order_id,
                        reason=(
                            "Reserved stock released after order cancellation"
                        ),
                        created_by=changed_by,
                    )
                )

        history = OrderStatusHistory(
            order_id=order_id,
            old_status=old_status,
            new_status=new_status,
            changed_by=changed_by,
            reason=data.reason,
        )

        db.add(history)

        # Create customer notifications for important order events.
        customer_notifications = {
            "Confirmed": (
                "Order Confirmed",
                f"Your order {order.order_number} has been confirmed.",
            ),
            "Shipped": (
                "Order Shipped",
                f"Your order {order.order_number} has been shipped.",
            ),
            "Delivered": (
                "Order Delivered",
                f"Your order {order.order_number} has been delivered.",
            ),
        }

        if new_status in customer_notifications:
            title, message = customer_notifications[new_status]

            create_notification(
                db=db,
                user_id=order.customer_id,
                title=title,
                message=message,
                notification_type="ORDER",
            )

        # Record order status change in audit logs.
        create_audit_log(
            db=db,
            user_id=changed_by,
            action="ORDER_STATUS_UPDATED",
            entity_type="ORDER",
            entity_id=order_id,
            description=(
                f"Order status changed from {old_status} "
                f"to {new_status}"
            ),
        )

        db.commit()
        db.refresh(history)

        return history

    except HTTPException:
        db.rollback()
        raise

    except Exception:
        db.rollback()
        raise
