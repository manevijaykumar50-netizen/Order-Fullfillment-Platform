from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.utils.enums import OrderStatus


class OrderAssignmentCreate(BaseModel):
    fulfillment_agent_id: int = Field(gt=0)


class OrderAssignmentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    order_id: int
    fulfillment_agent_id: int
    assigned_by: int | None
    status: str
    assigned_at: datetime
    updated_at: datetime


class OrderStatusUpdate(BaseModel):
    status: OrderStatus
    reason: str | None = Field(default=None, max_length=500)
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.utils.enums import OrderStatus


class OrderAssignmentCreate(BaseModel):
    fulfillment_agent_id: int = Field(gt=0)


class OrderAssignmentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    order_id: int
    fulfillment_agent_id: int
    assigned_by: int | None
    status: str
    assigned_at: datetime
    updated_at: datetime


class OrderStatusUpdate(BaseModel):
    status: OrderStatus
    reason: str | None = Field(default=None, max_length=500)
