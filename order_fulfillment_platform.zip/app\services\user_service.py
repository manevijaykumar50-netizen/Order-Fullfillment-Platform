from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.role import Role
from app.models.user import User
from app.schemas.user import (
    AdminCreateUserRequest,
    UpdateUserRoleRequest,
    UpdateUserStatusRequest,
)
from app.utils.enums import UserRole


def _get_role(db: Session, role_name: UserRole) -> Role:
    role = db.query(Role).filter(Role.name == role_name.value).first()

    if role is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Role '{role_name.value}' is not configured",
        )

    return role


def create_user_by_admin(
    db: Session,
    data: AdminCreateUserRequest,
) -> User:
    email = data.email.lower()

    existing_user = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email already exists",
        )

    role = _get_role(db, data.role)

    user = User(
        full_name=data.full_name,
        email=email,
        password_hash=hash_password(data.password),
        role_id=role.id,
        is_active=True,
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return user


def list_users(db: Session) -> list[User]:
    return (
        db.query(User)
        .order_by(User.id)
        .all()
    )


def update_user_role(
    db: Session,
    user_id: int,
    data: UpdateUserRoleRequest,
) -> User:
    user = (
        db.query(User)
        .filter(User.id == user_id)
        .first()
    )

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    role = _get_role(db, data.role)

    user.role_id = role.id

    db.commit()
    db.refresh(user)

    return user


def update_user_status(
    db: Session,
    user_id: int,
    data: UpdateUserStatusRequest,
) -> User:
    user = (
        db.query(User)
        .filter(User.id == user_id)
        .first()
    )

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    user.is_active = data.is_active

    db.commit()
    db.refresh(user)

    return user