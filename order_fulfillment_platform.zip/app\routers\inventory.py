
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.core.permissions import require_roles
from app.database import get_db
from app.models.user import User
from app.schemas.inventory import (
    InventoryCreate,
    InventoryResponse,
    InventoryReorderUpdate,
    InventoryStockAdjustment,
)
from app.services.inventory_service import (
    create_inventory,
    list_inventory,
    get_inventory,
    adjust_inventory_stock,
    update_inventory_reorder_level,
)
from app.utils.enums import UserRole


router = APIRouter(
    prefix="/inventory",
    tags=["Inventory"],
)


@router.post(
    "",
    response_model=InventoryResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_inventory_endpoint(
    data: InventoryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
        )
    ),
):
    return create_inventory(
        db,
        data,
        current_user.id,
    )


@router.get(
    "",
    response_model=list[InventoryResponse],
)

@router.get(
    "",
    response_model=list[InventoryResponse],
)
def get_inventory_list(
    warehouse_id: int | None = Query(default=None, gt=0),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
        )
    ),
):
    return list_inventory(
        db=db,
        warehouse_id=warehouse_id,
        skip=skip,
        limit=limit,
    )



@router.get(
    "/{inventory_id}",
    response_model=InventoryResponse,
)
def get_inventory_by_id(
    inventory_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
            UserRole.FULFILLMENT_AGENT,
        )
    ),
):
    return get_inventory(
        db,
        inventory_id,
    )


@router.post(
    "/{inventory_id}/stock-in",
    response_model=InventoryResponse,
)
def stock_in(
    inventory_id: int,
    data: InventoryStockAdjustment,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
        )
    ),
):
    return adjust_inventory_stock(
        db,
        inventory_id,
        data,
        current_user.id,
        increase=True,
    )


@router.post(
    "/{inventory_id}/stock-out",
    response_model=InventoryResponse,
)
def stock_out(
    inventory_id: int,
    data: InventoryStockAdjustment,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.WAREHOUSE_MANAGER,
        )
    ),
):
    return adjust_inventory_stock(
        db,
        inventory_id,
        data,
        current_user.id,
        increase=False,
    )


@router.patch(
    "/{inventory_id}/reorder-level",
    response_model=InventoryResponse,
)
def update_reorder_level(
    inventory_id: int,
    data: InventoryReorderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(UserRole.ADMIN)
    ),
):
    return update_inventory_reorder_level(
        db,
        inventory_id,
        data,
        current_user.id,
    )
