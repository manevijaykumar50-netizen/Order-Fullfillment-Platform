
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_engine
from app.models.inventory import Inventory
from app.models.notification import Notification
from app.models.warehouse_user import WarehouseUser

from app.services.notification_service import create_notification
from app.utils.enums import UserRole


def check_low_stock():
    """
    Scheduled task to identify low-stock inventory
    and notify warehouse managers.
    """

    engine = get_engine()

    with Session(engine) as db:
        try:
            inventories = db.scalars(
                select(Inventory).where(
                    Inventory.available_quantity
                    <= Inventory.reorder_level
                )
            ).all()

            for inventory in inventories:

                warehouse_managers = db.scalars(
                    select(WarehouseUser).where(
                        WarehouseUser.warehouse_id
                        == inventory.warehouse_id,
                        WarehouseUser.assignment_role
                        == UserRole.WAREHOUSE_MANAGER.value,
                    )
                ).all()

                message = (
                    f"Product {inventory.product_id} has only "
                    f"{inventory.available_quantity} units available. "
                    f"Reorder level: {inventory.reorder_level}."
                )

                for manager in warehouse_managers:

                    # Prevent duplicate notifications for the same alert.
                    existing_notification = db.scalar(
                        select(Notification.id).where(
                            Notification.user_id == manager.user_id,
                            Notification.title == "Low Stock Alert",
                            Notification.message == message,
                            Notification.notification_type == "INVENTORY",
                        ).limit(1)
                    )

                    if existing_notification is not None:
                        continue

                    create_notification(
                        db=db,
                        user_id=manager.user_id,
                        title="Low Stock Alert",
                        message=message,
                        notification_type="INVENTORY",
                    )

            db.commit()

        except Exception:
            db.rollback()
            raise
