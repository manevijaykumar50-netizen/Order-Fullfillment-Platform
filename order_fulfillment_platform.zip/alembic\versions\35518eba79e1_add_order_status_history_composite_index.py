"""add order status history composite index

Revision ID: 35518eba79e1
Revises: 3073f5dd6da1
Create Date: 2026-11-06 13:42:10.787064

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '35518eba79e1'
down_revision: Union[str, Sequence[str], None] = '3073f5dd6da1'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_index(
        "ix_order_status_history_order_created_at",
        "order_status_history",
        ["order_id", "created_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_order_status_history_order_created_at",
        table_name="order_status_history",
    )