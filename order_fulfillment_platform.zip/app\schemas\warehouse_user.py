
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class WarehouseUserCreate(BaseModel):
    warehouse_id: int = Field(gt=0)
    user_id: int = Field(gt=0)
    assignment_role: str = Field(
        min_length=1,
        max_length=50,
    )


class WarehouseUserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    warehouse_id: int
    user_id: int
    assignment_role: str
    assigned_at: datetime
