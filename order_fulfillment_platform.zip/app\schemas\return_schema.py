
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from app.utils.enums import ReturnStatus


class ReturnItemCreate(BaseModel):
    product_id: int = Field(gt=0)
    quantity: int = Field(gt=0, le=10000)


class ReturnCreate(BaseModel):
    order_id: int = Field(gt=0)
    reason: str = Field(min_length=3, max_length=2000)
    items: list[ReturnItemCreate] = Field(min_length=1, max_length=100)


class ReturnItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    product_id: int
    quantity: int
    unit_price: Decimal


class ReturnResponse(BaseModel):
    id: int
    order_id: int
    customer_id: int
    status: str
    reason: str
    refund_amount: Decimal | None
    requested_at: datetime
    updated_at: datetime
    items: list[ReturnItemResponse]


class ReturnStatusUpdate(BaseModel):
    status: ReturnStatus
